﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentsApp_console
{
    class Program
    {
        static void Main(string[] args)
        {

            Student[] students = new Student[] {
                new Student("Mary", "Blue"),
                new Student("Becky", "Blue"),
                new Student("Simon", "Smith", 15),
                new Student("Fanny", "Fargo"),
                new Student("Pete", "Smith", 9),
                new Student("Bill", "Bailey"),
                new Student("John", "Long"),
                new Student("Van", "Hill", 36),
                new Student("Cindy", "Jones"),
                new Student("Marcy", "Michaels", 18)
            };

            students[2].AddCredits(16);
            students[5].AddCredits(18);
            students[6].AddCredits(15);

            //Show all students
            Console.Write("\nAll students:\n");
            foreach (var s in students)
            {
                Console.WriteLine(s.ShowStudent());
            }

            //Aggregates
            int cntFT = 0;   //number of FT students
            int sumFT = 0;  //sum of all FT current credits

            Console.Write("\nFull-time students:\n");
            foreach (var s in students)
            {
                if (s.CurrentCredits >= 12)
                {
                    cntFT++;
                    sumFT += s.CurrentCredits;
                    Console.WriteLine(s.ShowStudent());
                }
            }

            Console.Write("\nNumber of FT students: ");
            Console.WriteLine(cntFT.ToString());
            Console.Write("\nSum of FT current credits: ");
            Console.WriteLine(sumFT.ToString());
            Console.Write("\nAverage FT current credits: ");
            if (cntFT > 0)
            {
                Console.WriteLine((sumFT / cntFT).ToString());
            }
            else
            {
                Console.WriteLine("Divide by zero error");
            }

            //Sequential Search
            Student stu = null; //flag 
            string strName = "Ong";
            int i;

            Console.WriteLine("\nSearching for: " + strName);

            for (i = 0; i < students.Count(); i++)
            {
                //if (students[i].StudentLastName.ToLower().IndexOf(strName.ToLower(),0) >= 0)
                if (students[i].StudentLastName.ToLower().Contains(strName.ToLower()))
                {
                    stu = students[i];
                    break;
                }

            }

            if (stu != null)
            {
                Console.WriteLine("Found " + stu.FullName + " at index " + i);
            }
            else
            {
                Console.WriteLine("Not found");
            }


            Console.ReadKey();

        }
    }
}
