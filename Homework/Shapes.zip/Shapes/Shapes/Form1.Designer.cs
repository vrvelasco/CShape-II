﻿
namespace Shapes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tetraSurfLabel = new System.Windows.Forms.Label();
            this.tetraVolLabel = new System.Windows.Forms.Label();
            this.tetraSizeLabel = new System.Windows.Forms.Label();
            this.sphereSurfLabel = new System.Windows.Forms.Label();
            this.sphereVolLabel = new System.Windows.Forms.Label();
            this.sphereSizeLabel = new System.Windows.Forms.Label();
            this.cubeSurfLabel = new System.Windows.Forms.Label();
            this.cubeVolLabel = new System.Windows.Forms.Label();
            this.cubeSizeLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.negativeButton = new System.Windows.Forms.Button();
            this.enlargeButton = new System.Windows.Forms.Button();
            this.biggerButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tetraSurfLabel
            // 
            this.tetraSurfLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tetraSurfLabel.Location = new System.Drawing.Point(281, 107);
            this.tetraSurfLabel.Name = "tetraSurfLabel";
            this.tetraSurfLabel.Size = new System.Drawing.Size(100, 23);
            this.tetraSurfLabel.TabIndex = 53;
            this.tetraSurfLabel.Text = "X";
            this.tetraSurfLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tetraVolLabel
            // 
            this.tetraVolLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tetraVolLabel.Location = new System.Drawing.Point(175, 107);
            this.tetraVolLabel.Name = "tetraVolLabel";
            this.tetraVolLabel.Size = new System.Drawing.Size(100, 23);
            this.tetraVolLabel.TabIndex = 52;
            this.tetraVolLabel.Text = "X";
            this.tetraVolLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tetraSizeLabel
            // 
            this.tetraSizeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tetraSizeLabel.Location = new System.Drawing.Point(69, 107);
            this.tetraSizeLabel.Name = "tetraSizeLabel";
            this.tetraSizeLabel.Size = new System.Drawing.Size(100, 23);
            this.tetraSizeLabel.TabIndex = 51;
            this.tetraSizeLabel.Text = "X";
            this.tetraSizeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sphereSurfLabel
            // 
            this.sphereSurfLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sphereSurfLabel.Location = new System.Drawing.Point(281, 72);
            this.sphereSurfLabel.Name = "sphereSurfLabel";
            this.sphereSurfLabel.Size = new System.Drawing.Size(100, 23);
            this.sphereSurfLabel.TabIndex = 50;
            this.sphereSurfLabel.Text = "X";
            this.sphereSurfLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sphereVolLabel
            // 
            this.sphereVolLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sphereVolLabel.Location = new System.Drawing.Point(175, 72);
            this.sphereVolLabel.Name = "sphereVolLabel";
            this.sphereVolLabel.Size = new System.Drawing.Size(100, 23);
            this.sphereVolLabel.TabIndex = 49;
            this.sphereVolLabel.Text = "X";
            this.sphereVolLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sphereSizeLabel
            // 
            this.sphereSizeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sphereSizeLabel.Location = new System.Drawing.Point(69, 72);
            this.sphereSizeLabel.Name = "sphereSizeLabel";
            this.sphereSizeLabel.Size = new System.Drawing.Size(100, 23);
            this.sphereSizeLabel.TabIndex = 48;
            this.sphereSizeLabel.Text = "X";
            this.sphereSizeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cubeSurfLabel
            // 
            this.cubeSurfLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cubeSurfLabel.Location = new System.Drawing.Point(281, 39);
            this.cubeSurfLabel.Name = "cubeSurfLabel";
            this.cubeSurfLabel.Size = new System.Drawing.Size(100, 23);
            this.cubeSurfLabel.TabIndex = 47;
            this.cubeSurfLabel.Text = "X";
            this.cubeSurfLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cubeVolLabel
            // 
            this.cubeVolLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cubeVolLabel.Location = new System.Drawing.Point(175, 39);
            this.cubeVolLabel.Name = "cubeVolLabel";
            this.cubeVolLabel.Size = new System.Drawing.Size(100, 23);
            this.cubeVolLabel.TabIndex = 46;
            this.cubeVolLabel.Text = "X";
            this.cubeVolLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cubeSizeLabel
            // 
            this.cubeSizeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cubeSizeLabel.Location = new System.Drawing.Point(69, 39);
            this.cubeSizeLabel.Name = "cubeSizeLabel";
            this.cubeSizeLabel.Size = new System.Drawing.Size(100, 23);
            this.cubeSizeLabel.TabIndex = 45;
            this.cubeSizeLabel.Text = "X";
            this.cubeSizeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(281, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 44;
            this.label6.Text = "Surface Area";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(175, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 23);
            this.label5.TabIndex = 43;
            this.label5.Text = "Volume";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(69, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.TabIndex = 42;
            this.label4.Text = "Size";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(12, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 23);
            this.label3.TabIndex = 41;
            this.label3.Text = "Tetra:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(12, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 23);
            this.label2.TabIndex = 40;
            this.label2.Text = "Sphere:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 23);
            this.label1.TabIndex = 39;
            this.label1.Text = "Cube:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // negativeButton
            // 
            this.negativeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.negativeButton.Location = new System.Drawing.Point(387, 107);
            this.negativeButton.Name = "negativeButton";
            this.negativeButton.Size = new System.Drawing.Size(138, 23);
            this.negativeButton.TabIndex = 38;
            this.negativeButton.Text = "Try a negative size";
            this.negativeButton.UseVisualStyleBackColor = true;
            this.negativeButton.Click += new System.EventHandler(this.negativeButton_Click);
            // 
            // enlargeButton
            // 
            this.enlargeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enlargeButton.Location = new System.Drawing.Point(387, 72);
            this.enlargeButton.Name = "enlargeButton";
            this.enlargeButton.Size = new System.Drawing.Size(138, 23);
            this.enlargeButton.TabIndex = 37;
            this.enlargeButton.Text = "Enlarge 10%";
            this.enlargeButton.UseVisualStyleBackColor = true;
            this.enlargeButton.Click += new System.EventHandler(this.enlargeButton_Click);
            // 
            // biggerButton
            // 
            this.biggerButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.biggerButton.Location = new System.Drawing.Point(387, 39);
            this.biggerButton.Name = "biggerButton";
            this.biggerButton.Size = new System.Drawing.Size(138, 23);
            this.biggerButton.TabIndex = 36;
            this.biggerButton.Text = "Create bigger shapes";
            this.biggerButton.UseVisualStyleBackColor = true;
            this.biggerButton.Click += new System.EventHandler(this.biggerButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 144);
            this.Controls.Add(this.tetraSurfLabel);
            this.Controls.Add(this.tetraVolLabel);
            this.Controls.Add(this.tetraSizeLabel);
            this.Controls.Add(this.sphereSurfLabel);
            this.Controls.Add(this.sphereVolLabel);
            this.Controls.Add(this.sphereSizeLabel);
            this.Controls.Add(this.cubeSurfLabel);
            this.Controls.Add(this.cubeVolLabel);
            this.Controls.Add(this.cubeSizeLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.negativeButton);
            this.Controls.Add(this.enlargeButton);
            this.Controls.Add(this.biggerButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Shapes";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label tetraSurfLabel;
        private System.Windows.Forms.Label tetraVolLabel;
        private System.Windows.Forms.Label tetraSizeLabel;
        private System.Windows.Forms.Label sphereSurfLabel;
        private System.Windows.Forms.Label sphereVolLabel;
        private System.Windows.Forms.Label sphereSizeLabel;
        private System.Windows.Forms.Label cubeSurfLabel;
        private System.Windows.Forms.Label cubeVolLabel;
        private System.Windows.Forms.Label cubeSizeLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button negativeButton;
        private System.Windows.Forms.Button enlargeButton;
        private System.Windows.Forms.Button biggerButton;
    }
}

