﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoApp
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.ReadKey();

            void ShowAutos(string title, IEnumerable<Auto> set)
            {
                Console.WriteLine($"\n {title}");
                Console.WriteLine($" {"Year",-5} {"MakeModel",-25} {"Cost",10} {"Price",10}");
                Console.WriteLine($" {"----",-5} {"---------",-25} {"----",10} {"-----",10}");
                foreach (var a in set)
                {
                    Console.WriteLine($" {a.Year,-5} {a.MakeModel,-25} {a.Cost,10:C} {a.Price,10:C}");
                }

            }
        }
    }

}
